<?php
// config.php
// Archivo central de configuración para el MVP Fintech.

// Base URL del proyecto (usada para generación de enlaces y QR)
define('BASE_URL', 'https://midominio.com/subcarpeta');

// Configuración de la Base de Datos
define('DB_HOST', 'localhost');
define('DB_NAME', 'fintech_mvp');
define('DB_USER', 'root');
define('DB_PASS', '');

// Configuración de JWT
define('JWT_SECRET', 'SUPER_SECRET_KEY_FOR_JWT_CHANGE_IN_PROD');

// Configuración de Correo SMTP
define('SMTP_HOST', 'smtp.midominio.com');
define('SMTP_PORT', 587); // Usualmente 587 para TLS o 465 para SSL
define('SMTP_USER', 'notificaciones@midominio.com');
define('SMTP_PASS', 'mi_password_seguro');
define('SMTP_FROM_EMAIL', 'notificaciones@midominio.com');
define('SMTP_FROM_NAME', 'Fintech MVP');
?>