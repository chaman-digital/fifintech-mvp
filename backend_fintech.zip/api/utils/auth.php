<?php
require_once __DIR__ . '/jwt.php';

function authenticate() {
    $headers = apache_request_headers();
    $authHeader = isset($headers['Authorization']) ? $headers['Authorization'] : '';

    if (empty($authHeader)) {
        http_response_code(401);
        echo json_encode(['message' => 'Authorization header missing']);
        exit;
    }

    $token = str_replace('Bearer ', '', $authHeader);
    $payload = JWT::decode($token);

    if (!$payload) {
        http_response_code(401);
        echo json_encode(['message' => 'Invalid or expired token']);
        exit;
    }

    return $payload;
}

function requireAdmin() {
    $user = authenticate();
    
    if (!isset($user['role']) || $user['role'] !== 'admin') {
        http_response_code(403);
        echo json_encode(['message' => 'Forbidden. Admin role required.']);
        exit;
    }
    
    return $user;
}
?>